# How to Train Your Dragon

## Calibrating ChatGPT to Create Region South Visuals

This kit helps another ChatGPT user reproduce the Region South visual system more consistently. It does **not** retrain OpenAI's image model. It creates a controlled working environment containing the correct instructions, authentic assets, approved visual references, request format, and validation process.

## Choose your route

### Route A — ChatGPT Work (recommended fast track)

Use this route when **Work** is available in ChatGPT.

1. Start a new Work task.
2. Add the contents of this kit as supporting files.
3. Open `WORK-INSTRUCTIONS.md` and paste its startup block into the task.
4. Complete `CALIBRATION-EXERCISE.md` before creating an official visual.
5. Evaluate the result with `VALIDATION-CHECKLIST.md`.
6. Use `CORRECTION-TEMPLATE.md` for revisions.

Work reduces repeated setup because it can use the goal, files, and context together during a structured creation workflow. It still needs the reference files and governing instructions.

### Route B — ChatGPT Project or regular Chat

Use this route when Work is unavailable.

1. Create a new Project named **Region South Visual Creator**. A dedicated Project is preferred over unrelated general chats.
2. Add the contents of this kit to the Project.
3. Copy `PROJECT-INSTRUCTIONS.md` into the Project instructions.
4. Begin a new Project chat and complete `CALIBRATION-EXERCISE.md`.
5. Evaluate the result with `VALIDATION-CHECKLIST.md`.
6. Keep approved outputs and related revisions inside the Project so later chats have relevant context.

If Projects are unavailable, upload the governing instructions, authentic assets, and relevant reference images directly to a new chat. Repeat the startup instructions whenever beginning a new chat.

## Before every image request

Complete `IMAGE-REQUEST-TEMPLATE.md`. ChatGPT should ask about any missing requirement before generating.

## Important expectations

- Separate image generations can differ even when the same prompt is used.
- Written rules alone do not fully communicate a visual system; reference images are required.
- A website link alone does not guarantee that ChatGPT will inspect every linked specification and reference.
- Iteration is normal. Give precise corrections instead of saying only that an image “doesn't look right.”
- Never accept an invented or approximated Region South or LAUSD logo.

## Authoritative online resources

- Human-facing guide: https://marioapodaca.github.io/region-south-hub/style-guide/
- AI-readable specification: https://marioapodaca.github.io/region-south-hub/style-guide/region-south-style-guide.md
- AI Quick Start: https://marioapodaca.github.io/region-south-hub/style-guide/AI-QUICKSTART.md
- Authentic Region South logo: https://github.com/marioapodaca/region-south-hub/blob/main/RS-logo.png
- Authentic LAUSD seal: https://github.com/marioapodaca/region-south-hub/blob/main/LAUSD_seal.png

