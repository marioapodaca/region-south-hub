# Repository and Website Integration Plan

## Proposed repository location

Add this package under:

`style-guide/chatgpt-calibration/`

Recommended structure:

```text
style-guide/chatgpt-calibration/
├── index.html                     # future user-facing guide
├── START-HERE.md
├── WORK-INSTRUCTIONS.md
├── PROJECT-INSTRUCTIONS.md
├── IMAGE-REQUEST-TEMPLATE.md
├── CALIBRATION-EXERCISE.md
├── VALIDATION-CHECKLIST.md
├── CORRECTION-TEMPLATE.md
├── REFERENCE-IMAGE-MANIFEST.md
├── Region-South-ChatGPT-Calibration-Kit.zip
└── approved-references/
```

## Visual Style Guide website additions

Add a primary navigation item or call-to-action labeled:

**Set Up ChatGPT**

Suggested description:

> Calibrate ChatGPT to apply the Region South visual system using authentic assets, approved references, guided requests, and a validation workflow.

The setup page should immediately offer:

- **ChatGPT Work — Fast Track**
- **Projects or regular Chat — Classic Track**
- **Download the Complete Calibration Kit**

## Important publishing rule

The website page explains the process, but the downloadable package supplies the actual files. Do not rely on website links alone as the complete working context for image generation.

