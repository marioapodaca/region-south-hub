# Authentic Brand Assets

These files were downloaded from the canonical Region South Hub repository:

- `RS-logo.png`
- `LAUSD_seal.png`

Use these assets exactly as supplied. Do not redraw, approximate, restyle, distort, recolor, or use a flattened logo from a reference image as a substitute.

The LAUSD seal should be included only when requested or otherwise required. Do not add it as decoration.

