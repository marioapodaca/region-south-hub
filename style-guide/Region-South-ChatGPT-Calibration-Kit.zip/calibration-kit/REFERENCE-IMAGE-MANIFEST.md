# Approved Reference Image Manifest

Use a small number of clearly labeled references. Each image has a specific purpose; no single image governs every design decision.

| File | Primary use | What to learn from it |
|---|---|---|
| `01-dark-math-infographic.png` | Dark Mode Math | Navy background, blue hierarchy, chart/panel integration, student placement |
| `02-light-data-infographic.png` | Light Mode data | White canvas, blue section bars, comparative charts, callout column |
| `03-dark-presentation-title.png` | Dark title slide | Centered hierarchy, atmospheric background, student imagery framing |
| `04-light-algebra-title.png` | Light title slide | White space, blue wave structure, subject-specific mathematical details |
| `05-dark-math-guideposts.png` | Math guideposts | Three-panel system, calculator iconography, Math blue treatment |
| `06-dark-ela-guideposts.png` | ELA guideposts | Three-panel system, ELA orange hierarchy, reading/writing iconography |
| `07-dark-science-guideposts.png` | Science guideposts | Three-panel system, Science green hierarchy, science iconography |

## Usage instructions

- Identify which image controls the overall layout.
- Identify which image controls the subject color and icon treatment.
- Identify which image controls student placement when people are included.
- Do not copy numbers, claims, dates, or source labels from a reference image.
- Do not treat a logo visible inside a flattened reference image as a reusable authentic logo asset.
- Use the separately supplied authentic logo files for new designs.

